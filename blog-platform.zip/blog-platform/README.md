# Blog Platform with Comments

## Project Setup

1. Extract the Zip file.
2. Open terminal in the project folder.
3. Install dependencies:
   ```bash
   npm install
   ```
4. Start MongoDB service on your local machine.
5. Start the server:
   ```bash
   npm start
   ```
6. Open `http://localhost:5000` in your browser.
